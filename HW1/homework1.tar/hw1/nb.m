function [ v ] = nb( d, t )
%   Naive Bayes algorithm
%   Fill in your codes here.

v = [0];

end
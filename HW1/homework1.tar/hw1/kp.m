function [ v ] = kp( d, t )
%   KP Kernel / Featurized Perceptron algorithm
%   Fill in your codes here.

v = [0];

end


function [ v ] = lp( d, t )
%   LP Linear Perceptron algorithm
%   Fill in your codes here.

v = [0];

end

